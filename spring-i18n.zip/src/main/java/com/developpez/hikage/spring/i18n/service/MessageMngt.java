package com.developpez.hikage.spring.i18n.service;


public interface MessageMngt {

    public String getMessage(String key, String langue, String pays);

}
